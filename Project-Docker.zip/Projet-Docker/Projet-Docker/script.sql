-- script.sql
CREATE TABLE todo (
    id SERIAL PRIMARY KEY,
    titre VARCHAR(100) NOT NULL,
    done BOOLEAN NOT NULL
);

INSERT INTO todo (titre, done) VALUES ('Tâche 1', true);
INSERT INTO todo (titre, done) VALUES ('Tâche 2', false);
INSERT INTO todo (titre, done) VALUES ('Tâche 3', false);
INSERT INTO todo (titre, done) VALUES ('Tâche 4', true);
INSERT INTO todo (titre, done) VALUES ('Tâche 5', true);
INSERT INTO todo (titre, done) VALUES ('Tâche 6', false);
INSERT INTO todo (titre, done) VALUES ('Tâche 7', false);
INSERT INTO todo (titre, done) VALUES ('Tâche 8', true);
INSERT INTO todo (titre, done) VALUES ('Tâche 9', false);
INSERT INTO todo (titre, done) VALUES ('Tâche 10', true);
